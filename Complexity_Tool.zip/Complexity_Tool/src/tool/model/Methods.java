package tool.model;

public class Methods {

	int lineNumber, primitive_method,composite_method,primitive_parameters,composite_parameters;
	String line;
	
	public int getLineNumber() {
		return lineNumber;
	}
	public void setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
	}
	public int getPrimitive_method() {
		return primitive_method;
	}
	public void setPrimitive_method(int primitive_method) {
		this.primitive_method = primitive_method;
	}
	public int getComposite_method() {
		return composite_method;
	}
	public void setComposite_method(int composite_method) {
		this.composite_method = composite_method;
	}
	public int getPrimitive_parameters() {
		return primitive_parameters;
	}
	public void setPrimitive_parameters(int primitive_parameters) {
		this.primitive_parameters = primitive_parameters;
	}
	public int getComposite_parameters() {
		return composite_parameters;
	}
	public void setComposite_parameters(int composite_parameters) {
		this.composite_parameters = composite_parameters;
	}
	public String getLine() {
		return line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	
}
